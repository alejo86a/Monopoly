/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Turovskiy Vladyslav
 */
public class Free extends Cell {
     Free(String s,int i)
    {
    super(s,i);
    super.setNumb_monopoly(0);
    }
     Free(){}
     @Override
     void action()
     {
     
     }
}
