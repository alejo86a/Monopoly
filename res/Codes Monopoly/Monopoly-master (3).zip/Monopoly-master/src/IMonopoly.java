/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Turovskiy Vladyslav
 */
 interface IMonopoly {
    boolean monopoly_check(int n);
}
