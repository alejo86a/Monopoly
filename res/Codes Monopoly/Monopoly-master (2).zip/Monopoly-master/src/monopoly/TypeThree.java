package monopoly;

public class TypeThree extends LandType{
    int getTypePrice() {
        return 300;
    }
}
