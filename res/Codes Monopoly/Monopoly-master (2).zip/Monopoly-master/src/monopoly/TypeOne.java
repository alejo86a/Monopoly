package monopoly;

public class TypeOne extends LandType {
     int getTypePrice() {
        return 200;
    }
}
