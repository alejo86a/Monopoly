package monopoly;

public class main {
    public static void main(String[] args) {
        GameProcess gameProcess = new GameProcess();
        gameProcess.run();
    }
}
