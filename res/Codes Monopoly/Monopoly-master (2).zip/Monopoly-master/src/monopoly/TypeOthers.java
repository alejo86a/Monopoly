package monopoly;

public class TypeOthers extends LandType{

}
