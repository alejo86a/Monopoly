package monopoly;

public class TypeTwo extends LandType{
    int getTypePrice() {
        return 500;
    }
}
