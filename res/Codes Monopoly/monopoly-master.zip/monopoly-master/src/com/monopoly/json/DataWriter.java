package com.monopoly.json;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;
import com.monopoly.internal.money.Money;

/**
 * This class is used to rebuild the {@code .json} file that contains
 * information about the cards of this game.
 * 
 * @author kmchen1
 * 
 */
public class DataWriter {

    /**
     * The {@code JSONObject} key for the types of {@link Money}.
     */
    public static final String MONEY_KEY = "money";

    /**
     * The {@code JSONObject} key for the types of {@link WhiteRussian}s.
     */
    public static final String WHITE_RUSSIANS_KEY = "white_russians";

    /**
     * The {@code JSONObject} key for the types of {@link Utility}s.
     */
    public static final String UTILITIES_KEY = "utilities";

    /**
     * The {@code JSONObject} key for the types of {@link Railroad}s.
     */
    public static final String RAILROADS_KEY = "railroads";

    /**
     * The {@code JSONObject} key for the types of {@link Briefcase}s.
     */
    public static final String BRIEFCASES_KEY = "briefcases";

    /**
     * The {@code JSONObject} key for the types of {@link Property}s.
     */
    public static final String PROPERTIES_KEY = "properties";

    /**
     * The {@code JSONObject} key for descriptions.
     */
    public static final String DESCRIPTION_KEY = "description";

    /**
     * The White Russians.
     */
    public static final String[] WHITE_RUSSIANS = new String[] { "Pay each player $50.", "Pass out. Do not observe Shabbos.", "Collect $100.",
            "Pay $15.", "Advance to the Dude's ride. If you observe Shabbos, collect $200.", "Pay $150.", "Go back 3 spaces.", "Pay $50.",
            "Wake up.", "Advance to Shabbos. Collect $200.", "Advance to Doctor's Office. If you observe Shabbos, colelct $200.", "Collect $50.",
            "Advance to Lebowski's mansion.", "Collect $150.",
            "Advance to nearest utility. If owned, throw dice and pay owner ten times the amount thrown.",
            "Advance to nearest car. Pay owner twice the rental.", "Pay $25 for each house, $100 for each hotel.", };
    
    /**
     * Writes a {@code JSONObject} to file.
     * 
     * @param obj
     *            The JSONObject to write to file.
     * @param path
     *            The path of the file to be written to.
     */
    public static void write(JSONObject obj, String path) {
        try {
            FileWriter file = new FileWriter(path);
            file.write(obj.toJSONString());
            file.flush();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns a {@code JSONObject} with one or more key/value pairs.
     * 
     * @param keys
     *            There must be just as many keys as values.
     * @param values
     *            There must be just as many values as keys.
     * @return a {@code JSONObject} with one or more key/value pairs.
     */
    private static JSONObject createJSONObject(String[] keys, String... values) {
        if (keys.length != values.length) {
            throw new IllegalArgumentException("Keys and values must be same length.");
        }
        JSONObject obj = new JSONObject();
        for (int i = 0; i < keys.length; i++) {
            obj.put(keys[i], values[i]);
        }
        return obj;
    }

    public static void main(String[] args) {
        final String path = "info.json";

        // The top-level object
        JSONObject obj = new JSONObject();

        // The sub-levels
        JSONObject money = new JSONObject();
        JSONObject whiteRussians = new JSONObject();
        JSONObject utilities = new JSONObject();
        JSONObject railroads = new JSONObject();
        JSONObject briefcases = new JSONObject();
        JSONObject properties = new JSONObject();

        // Build money object
        money.put(Integer.valueOf(1), "White");
        money.put(Integer.valueOf(5), "Pink");
        money.put(Integer.valueOf(10), "Yellow");
        money.put(Integer.valueOf(20), "Green");
        money.put(Integer.valueOf(50), "Blue");
        money.put(Integer.valueOf(100), "Beige");
        money.put(Integer.valueOf(500), "Orange");

        // Build WhiteRussians
        for (int i = 0; i < WHITE_RUSSIANS.length; i++) {
            whiteRussians.put(Integer.valueOf(i + 1), createJSONObject(new String[] { DESCRIPTION_KEY }, WHITE_RUSSIANS[i]));
        }

        // Build top-level object
        obj.put(MONEY_KEY, money);
        obj.put(WHITE_RUSSIANS_KEY, whiteRussians);
        obj.put(UTILITIES_KEY, utilities);
        obj.put(RAILROADS_KEY, railroads);
        obj.put(BRIEFCASES_KEY, briefcases);
        obj.put(PROPERTIES_KEY, properties);

        // JSONArray list = new JSONArray();
        // list.add("msg 1");

        // write(obj, path);
        System.out.print(obj);

    }
}
