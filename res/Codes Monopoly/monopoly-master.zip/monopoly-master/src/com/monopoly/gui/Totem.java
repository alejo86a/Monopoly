/**
 * 
 */
package com.monopoly.gui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

import org.imgscalr.Scalr;

/**
 * @author kmchen1
 *
 */
class Totem extends JPanel implements ActionListener {

    private final int imageNo;
    private BufferedImage image;
    private final JPanel parent;
    
    public Totem(final JPanel parent, final int imageNo) {
        super();
        this.imageNo = imageNo;
        this.parent = parent;
        String path = Game.TOTEM_PATH + imageNo + ".png";
        try {
            image = ImageIO.read(new File(path));
        } catch (IOException e) {
            System.err.println("Couldn't read: " + path);
            e.printStackTrace();
        }
        setBorder(BorderFactory.createRaisedBevelBorder());
    }

    @Override
    public Dimension getPreferredSize() {
        System.out.println(parent.getWidth() + " x " + parent.getHeight());
        
        return new Dimension(parent.getWidth() / Game.MAX_PLAYERS, parent.getHeight());
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage b = Scalr.resize(image, Scalr.Method.ULTRA_QUALITY, Scalr.Mode.FIT_TO_HEIGHT, getWidth(), parent.getHeight(), Scalr.OP_ANTIALIAS);
        int xPad = (getWidth() - b.getWidth()) / 2;
        g.drawImage(b, xPad, 0, null);
    }

    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent arg0) {
        Dimension d = getPreferredSize();
        System.out.println(d.width + " x " + d.height);
        
    }
    
}
