/**
 * 
 */
package com.monopoly.gui;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import com.monopoly.internal.Player;

/**
 * @author kmchen1
 *
 */
class TotemPanel extends JPanel {
    
    public TotemPanel(Vector<Player> players) {
        super();
        setBorder(BorderFactory.createLineBorder(Color.BLUE));
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = 1;
        c.gridheight = 10;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        final int inset = 30;
        c.insets = new Insets(inset, inset, inset, inset);
        c.gridy = 0;
        
        for (int i = 0; i < players.size(); i++) {
            c.gridx = i;
            add(new Totem(this, players.get(i).getID()));
        }

    }

    
    
}
