package com.monopoly.gui;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;

import com.monopoly.internal.Player;

/**
 * This class prompts the user to pick a totem and enter a name.
 * 
 * @author Kevin Chen
 */
public class ChooseTotemWindow extends JFrame implements ActionListener, KeyListener {

    private static final long serialVersionUID = 1L;
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;
    private JButton b7;
    private JTextFieldLimit tf;
    private Game game;

    /**
     * Constructs a Totem Window.
     */
    public ChooseTotemWindow(Game game) {
        super("Enter a name, then pick a totem...");
        this.game = game;
        setLayout(new GridBagLayout());
        initButtons();

        // Add stuff to frame
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(5, 5, 5, 5);
        add(createTotemPanel(), c);

        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(5, 5, 5, 5);
        add(createNamePanel(), c);

        // Frame Settings
        getRootPane().setDefaultButton(b1);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
        pack();
    }

    /**
     * If the user clicks on a Totem button, it becomes his totem.
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        // The object which detected the action
        Object obj = e.getSource();

        String name = tf.getText();

        if (isValidName(name)) {
            Player player = null;
            if (obj == b1) {
                player = new Player(name, 1);
            }
            else if (obj == b2) {
                player = new Player(name, 2);
            }
            else if (obj == b3) {
                player = new Player(name, 3);
            }
            else if (obj == b4) {
                player = new Player(name, 4);
            }
            else if (obj == b5) {
                player = new Player(name, 5);
            }
            else if (obj == b6) {
                player = new Player(name, 6);
            }
            else {
                player = new Player(name, 7);
            }
            game.getFrame().setVisible(true);
            game.addPlayer(player);
            dispose();
        }
        else {
            JOptionPane.showMessageDialog(null, "Name length must be between 3 and 10 characters.");
        }
    }

    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
        int id = e.getID();
        String newName = tf.getText();
        Character key = new Character(e.getKeyChar());

        // Make sure the char is typed and valid
        if (id != KeyEvent.KEY_TYPED || !isValidChar(key))
            return;

        // If we're not already at the maximum...
        if (newName.length() < Player.MAX_CHAR_NAME) {
            tf.setText(newName);
        }
        // If we are at the maximum...
        else {
            // Truncate the last character
            String oldName = newName.substring(0, newName.length() - 1);
            tf.setText(oldName);
        }
    }

    /**
     * Creates the Totem panel.
     * 
     * @return The panel displaying totems for user selection.
     */
    private JPanel createTotemPanel() {
        JPanel totemPanel = new JPanel();
        // Add totem buttons to totem panel
        totemPanel.add(b1);
        totemPanel.add(b2);
        totemPanel.add(b3);
        totemPanel.add(b4);
        totemPanel.add(b5);
        totemPanel.add(b6);
        totemPanel.add(b7);
        totemPanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
        // totemPanel.setFocusTraversalKeysEnabled(true);
        return totemPanel;
    }

    private JPanel createNamePanel() {
        JPanel namePanel = new JPanel();

        // The label
        final JLabel enterNameLabel = new JLabel("Enter name: ");
        enterNameLabel.setFont(new Font("Arial", Font.BOLD, 18));

        // The text field
        tf = new JTextFieldLimit(Player.MAX_CHAR_NAME, 15);
        tf.setFocusTraversalKeysEnabled(true);
        tf.setFont(new Font("Verdana", Font.PLAIN, 15));
        tf.addKeyListener(this);
        tf.requestFocusInWindow();

        // Add text field and label to name panel.
        namePanel.add(Box.createHorizontalStrut(5));
        namePanel.add(enterNameLabel);
        namePanel.add(Box.createHorizontalStrut(5));
        namePanel.add(new JSeparator(SwingConstants.VERTICAL));
        namePanel.add(tf);
        namePanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
        return namePanel;
    }

    private void initButtons() {
        File f1 = new File(Game.TOTEM_PATH + File.separator + "1.png");
        File f2 = new File(Game.TOTEM_PATH + File.separator + "2.png");
        File f3 = new File(Game.TOTEM_PATH + File.separator + "3.png");
        File f4 = new File(Game.TOTEM_PATH + File.separator + "4.png");
        File f5 = new File(Game.TOTEM_PATH + File.separator + "5.png");
        File f6 = new File(Game.TOTEM_PATH + File.separator + "6.png");
        File f7 = new File(Game.TOTEM_PATH + File.separator + "7.png");
        BufferedImage i1 = null, i2 = null, i3 = null, i4 = null, i5 = null, i6 = null, i7 = null;
        try {
            i1 = ImageIO.read(f1);
            i2 = ImageIO.read(f2);
            i3 = ImageIO.read(f3);
            i4 = ImageIO.read(f4);
            i5 = ImageIO.read(f5);
            i6 = ImageIO.read(f6);
            i7 = ImageIO.read(f7);
        } catch (IOException e) {
            System.err.println("initButtons error");
            e.printStackTrace();
        }
        b1 = new JButton((Icon) new ImageIcon((Image) i1));
        b2 = new JButton((Icon) new ImageIcon((Image) i2));
        b3 = new JButton((Icon) new ImageIcon((Image) i3));
        b4 = new JButton((Icon) new ImageIcon((Image) i4));
        b5 = new JButton((Icon) new ImageIcon((Image) i5));
        b6 = new JButton((Icon) new ImageIcon((Image) i6));
        b7 = new JButton((Icon) new ImageIcon((Image) i7));

        // Add Action Listeners
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);

    }

    private boolean isValidName(String name) {
        int len = name.length();
        return (len >= Player.MIN_CHAR_NAME && len <= Player.MAX_CHAR_NAME);
    }

    private boolean isValidChar(Character key) {
        return isLetter(key) || isDigit(key);
    }

    private boolean isLetter(Character key) {
        return Character.isLetter(key);
    }

    private boolean isDigit(Character key) {
        return Character.isDigit(key);
    }

}
