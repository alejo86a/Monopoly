package com.monopoly.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.imgscalr.Scalr;

import com.monopoly.internal.Player;
import com.monopoly.internal.board.Board;
import com.monopoly.internal.board.Tile;
import com.monopoly.internal.decks.DeckFactory;
import com.monopoly.internal.decks.NonownableDeck;
import com.monopoly.internal.money.Bank;

/**
 * A GUI to run the game.
 * 
 * @author Kevin Chen
 */
public class Game {

    /**
     * The path to the directory of images.
     */
    public final static String IMAGE_PATH = "res";

    /**
     * The path to the directory of totem images.
     */
    public final static String TOTEM_PATH = IMAGE_PATH + "/totems/";

    /**
     * The path to the directory of <tt>Briefcase</tt> card images.
     */
    public final static String BRIEFCASE_PATH = IMAGE_PATH + "/briefcase/";

    /**
     * The path to the directory of <tt>WhiteRussian</tt> card images.
     */
    public final static String WHITE_RUSSIANS_PATH = IMAGE_PATH + "/white_russians/";

    /**
     * The path to the directory of <tt>Property</tt> card images.
     */
    public final static String PROPERTIES_PATH = IMAGE_PATH + "/properties/";

    /**
     * The maximum number of possible players.
     */
    public final static int MAX_PLAYERS = 7;

    private JFrame frame;
    private final static int MIN_WIDTH = 800;
    private final static int MIN_HEIGHT = 600;

    private final static String TITLE = "Monopoly: Big Lebowski";

    private final NonownableDeck WRdeck;
    private final NonownableDeck BCdeck;
    private final Board board;
    private final Bank bank;
    private final Vector<Player> players;
    private final Random random;
    private static BufferedImage boardImage;
    private int turn = 0;
    private boolean isOver = false;

    /**
     * Debug constructor. Skips totem window.
     * 
     * @param debug
     *            Will debug regardless.
     */
    public Game(boolean debug) {
        players = new Vector<Player>(Game.MAX_PLAYERS);
        WRdeck = DeckFactory.newWhiteRussianDeck();
        BCdeck = DeckFactory.newBriefcaseDeck();
        board = new Board();
        random = new Random();
        bank = new Bank();
        buildUI();
        addPlayer(new Player("Gabby", 1));
        addPlayer(new Player("Kevin", 2));
        getFrame().setVisible(true);
        dealMoney();
        nextTurn();
    }

    /**
     * 
     */
    private void nextTurn() {
        if (isOver) {
            frame.setTitle("Game Over!");
            return;
        }
        int playerIndex = turn % players.size();
        Player player = players.get(playerIndex);
        int roll1 = rollDie();
        int roll2 = rollDie();
        int pos1 = player.getPosition();
        player.goForward(roll1 + roll2);
        int pos2 = player.getPosition();
        Tile tile = board.getTile(pos2);
        String roll = player.getName() + " rolled a " + roll1 + " and a " + roll2 + ",\n";
        roll += "moving you from Tile " + pos1 + " to Tile " + pos2 + ".\n";
        roll += "You landed on " + tile.getType() + ".\n";
        switch (tile.getType()) {
            case BRIEFCASE:
                break;
            case FEE:
                break;
            case GUTTERBALLS:
                break;
            case JAIL:
                break;
            case PROPERTY:
                break;
            case RAILROAD:
                break;
            case SHABBOS:
                break;
            case TOJAIL:
                break;
            case UTILITY:
                break;
            case WHITERUSSIAN:
                break;
            default:
                break;
        }
        turn++;
    }

    /**
     * Constructs a <tt>Game</tt> frame to run the program.
     */
    public Game() {
        players = new Vector<Player>(Game.MAX_PLAYERS);
        WRdeck = DeckFactory.newWhiteRussianDeck();
        BCdeck = DeckFactory.newBriefcaseDeck();
        board = new Board();
        random = new Random();
        bank = new Bank();
        buildUI();
        new ChooseTotemWindow(this);
        dealMoney();
    }

    /**
     * Hands out $1000 to each player.
     */
    protected void dealMoney() {
        for (Player player : players) {
            System.out.format("Just dealt to %s\n", player.getName());
            bank.give(player, 1000);
        }
        System.out.println(bank);
    }

    /**
     * Returns this <tt>Game</tt>'s frame.
     * 
     * @return This <tt>Game</tt>'s frame.
     */
    public JFrame getFrame() {
        return frame;
    }

    /**
     * Adds a player to the <tt>Game</tt>'s list of players.
     * 
     * @param player
     *            The player to be added.
     */
    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * Builds the user interface.
     */
    private void buildUI() {

        // Create frame
        frame = new JFrame(TITLE);
        frame.setMinimumSize(new Dimension(MIN_WIDTH, MIN_HEIGHT));
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        // Add board at 0,0
        int boardWidth = 3;
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = boardWidth;
        c.gridheight = boardWidth;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(5, 5, 5, 5);
        frame.add(createBoardPanel(), c);

        // Add control panel at 1,0
        c.gridx = boardWidth;
        c.gridy = 0;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.1;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(5, 5, 5, 5);
        frame.add(createControlPanel(), c);

        // Add totem panel at 0,1
        c.gridx = 0;
        c.gridy = boardWidth;
        c.weightx = 1.0;
        c.weighty = 0.1;
        frame.add(new TotemPanel(players), c);

        frame.pack();
    }

    /**
     * Creates the panel that shows the board.
     * 
     * @return The panel that shows the board.
     */
    private JPanel createBoardPanel() {
        String pathToBoard = IMAGE_PATH + File.separator + "small board.png";
        try {
            boardImage = ImageIO.read(new File(pathToBoard));
        } catch (IOException e) {
            System.err.println("Couldn't read: " + pathToBoard);
            e.printStackTrace();
        }

        JPanel boardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                BufferedImage b = Scalr.resize(boardImage, Scalr.Method.ULTRA_QUALITY, Scalr.Mode.FIT_TO_HEIGHT, getWidth(), getHeight(),
                        Scalr.OP_ANTIALIAS);
                int xPad = (getWidth() - b.getWidth()) / 2;
                g.drawImage(b, xPad, 0, null);
            }
        };
        boardPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE));
        // boardPanel.add(new JLabel(new ImageIcon(board)));
        return boardPanel;
    }

    /**
     * Creates the panel with buttons.
     * 
     * @return The panel with buttons so user can decide what to do.
     */
    private JPanel createControlPanel() {
        JPanel controlPanel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        // Buttons
        JButton rollButton = new JButton("Roll");
        rollButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rollButtonPressed();
            }
        });
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton b4 = new JButton("4");

        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        c.ipadx = 10;
        c.ipady = 10;
        c.insets = new Insets(5, 5, 5, 5);

        c.gridx = 0;
        c.gridy = 0;
        controlPanel.add(rollButton, c);

        c.gridx = 1;
        c.gridy = 0;
        controlPanel.add(b2, c);

        c.gridx = 0;
        c.gridy = 1;
        controlPanel.add(b3, c);

        c.gridx = 1;
        c.gridy = 1;
        controlPanel.add(b4, c);

        return controlPanel;
    }

    protected int rollDie() {
        return random.nextInt(6) + 1;
    }

    protected void rollButtonPressed() {
        System.out.format("%s, player %d\n", players.get(0).getName(), 0);
        System.out.format("You rolled a %d and a %d\n", rollDie(), rollDie());
    }

    /* Main method */
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Game game = new Game(true);

            }
        });
    }

}
