package com.monopoly.internal.board;

import com.monopoly.internal.Player;
import com.monopoly.internal.cards.Card;

/**
 * {@code Tile}s store information about all possible places on the
 * {@code Board} a {@code Player} can land.
 * 
 * @author kmchen1
 * 
 */
public class Tile {

    private final TileType type;
    private final Card card;
    private Player owner = null;

    /**
     * Constructs a {@code Tile} from a {@code TileType} (e.g., RAILROAD) and a
     * {@code Card} (e.g., Angry Cabby).
     * 
     * @param type
     *            The type of this {@code Tile}.
     * @param card
     *            The specific card of this {@code Tile}.
     */
    public Tile(TileType type, Card card) {
        this.type = type;
        this.card = card;
    }

    /**
     * Checks to see if this {@code Tile} is owned.
     * 
     * @return True if the {@code Player} who owns this {@code Tile} is
     *         non-null.
     */
    public boolean isOwned() {
        return owner != null;
    }

    /**
     * Returns the {@code Player} who owns this {@code Tile}.
     * 
     * @return the {@code Player} who owns this {@code Tile}.
     */
    public Player getOwner() {
        return owner;
    }

    /**
     * Returns the {@code TileType} of this {@code Tile}.
     * 
     * @return The {@code TileType} of this {@code Tile}.
     */
    public TileType getType() {
        return type;
    }

    /**
     * Returns this {@code Tile}'s {@code Card}.
     * 
     * @return this {@code Tile}'s {@code Card}.
     */
    public Card getCard() {
        return card;
    }

    /**
     * Checks to see if this {@code Tile} is a {@code Property}.
     * 
     * @return True if this {@code Tile} is a {@code Property}.
     */
    public boolean isProperty() {
        return type == TileType.PROPERTY;
    }

    /**
     * Checks to see if this {@code Tile} is a {@code Railroad}.
     * 
     * @return True if this {@code Tile} is a {@code Railroad}.
     */
    public boolean isRailroad() {
        return type == TileType.RAILROAD;
    }

    /**
     * Checks to see if this {@code Tile} is a {@code Utility}.
     * 
     * @return True if this {@code Tile} is a {@code Utility}.
     */
    public boolean isUtility() {
        return type == TileType.UTILITY;
    }

    /**
     * Checks to see if this {@code Tile} is a fee.
     * 
     * @return True if this {@code Tile} is a fee.
     */
    public boolean isFee() {
        return type == TileType.FEE;
    }

    /**
     * Checks to see if this {@code Tile} is Shabbos (the GO space).
     * 
     * @return True if this {@code Tile} is Shabbos (the GO space).
     */
    public boolean isShabbos() {
        return type == TileType.SHABBOS;
    }

    /**
     * Checks to see if this {@code Tile} is the jail.
     * 
     * @return True if this {@code Tile} is the jail.
     */
    public boolean isJail() {
        return type == TileType.JAIL;
    }

    public boolean isToJail() {
        return type == TileType.TOJAIL;
    }

    public boolean isGutterballs() {
        return type == TileType.GUTTERBALLS;
    }
}
