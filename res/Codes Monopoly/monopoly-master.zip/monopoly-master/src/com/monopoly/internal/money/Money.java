package com.monopoly.internal.money;

import java.util.Comparator;

/**
 * Enumeration of currency bills.
 * 
 * @author Kevin Chen
 */
public enum Money {

    //@formatter:off
    M500("Orange", 500),
	M100("Beige", 100),
	M50("Blue", 50),
	M20("Green", 20),
	M10("Yellow", 10),
	M5("Pink", 5),
	M1("White", 1);
	//@formatter:on

    /**
     * A <tt>Comparator</tt> to sort money from smallest to biggest.
     */
    public final static Comparator<Money> comparator = new Comparator<Money>() {
        @Override
        public int compare(Money o1, Money o2) {
            return o1.getValue() - o2.getValue();
        }
    };
    
    /**
     * The color of the bill.
     */
    private final String color;

    /**
     * The value of the bill.
     */
    private final int value;

    /**
     * Constructs money.
     * 
     * @param color
     *            The color of the bill.
     * @param value
     *            The value of the bill.
     */
    private Money(String color, int value) {
        this.color = color;
        this.value = value;
    }

    /**
     * Returns the <code>String</code> representation of this money's color.
     * 
     * @return This money's color.
     */
    public String getColor() {
        return color;
    }

    /**
     * Returns this money's value.
     * 
     * @return This money's value.
     */
    public int getValue() {
        return value;
    }

}
