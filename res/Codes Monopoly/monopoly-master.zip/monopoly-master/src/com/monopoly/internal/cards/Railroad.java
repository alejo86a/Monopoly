package com.monopoly.internal.cards;

/**
 * An enumeration of railroad spots.
 * 
 * @author Kevin Chen
 */
public enum Railroad implements OwnableCard {

    //@formatter:off
    /**
     * Angry Cabby.
     */
	ANGRY_CABBY("Angry Cabby", 25, 50, 100, 200, 100, 25),
	
	/**
	 * Lebowski's Limo.
	 */
	LEBOWSKIS_LIMO("Lebowski's Limo", 25, 50, 100, 200, 100, 26),
	
	/**
	 * Tony's Limo.
	 */
	TONYS_LIMO("Tony's Limo", 25, 50, 100, 200, 100, 27),
	
	/**
	 * The Dude's Ride.
	 */
	DUDES_RIDE("The Dude's Ride", 25, 50, 100, 200, 100, 28);
	//@formatter:on

    private final String description;
    private final int rent1;
    private final int rent2;
    private final int rent3;
    private final int rent4;
    private final int mortgage;
    private final int id;

    /**
     * Constructs a {@code Railroad}.
     * 
     * @param description
     *            The {@code Railroad}'s description.
     * @param rent1
     *            The railroad's rent if the owner owns 1 {@code Railroad}.
     * @param rent2
     *            The railroad's rent if the owner owns 2 {@code Railroad}s.
     * @param rent3
     *            The railroad's rent if the owner owns 3 {@code Railroad}s.
     * @param rent4
     *            The railroad's rent if the owner owns 4 {@code Railroad}s.
     * @param mortgage
     *            The mortgage value of this {@code Railroad}.
     * @param id
     *            The id of this {@code Railroad}.
     */
    Railroad(String description, int rent1, int rent2, int rent3, int rent4, int mortgage, int id) {
        this.description = description;
        this.rent1 = rent1;
        this.rent2 = rent2;
        this.rent3 = rent3;
        this.rent4 = rent4;
        this.mortgage = mortgage;
        this.id = id;
    }

    /**
     * Returns the description of this {@code Railroad}.
     * 
     * @return The description of this {@code Railroad}.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns the rent cost of landing on this {@code Railroad}'s tile if the
     * owner owns 1 railroad.
     * 
     * @return The rent cost of landing on this {@code Railroad}'s tile if the
     *         owner owns 1 railroad.
     */
    public int getRent1() {
        return rent1;
    }

    /**
     * Returns the rent cost of landing on this {@code Railroad}'s tile if the
     * owner owns 2 railroads.
     * 
     * @return The rent cost of landing on this {@code Railroad}'s tile if the
     *         owner owns 2 railroads.
     */
    public int getRent2() {
        return rent2;
    }

    /**
     * Returns the rent cost of landing on this {@code Railroad}'s tile if the
     * owner owns 3 railroads.
     * 
     * @return The rent cost of landing on this {@code Railroad}'s tile if the
     *         owner owns 3 railroads.
     * 
     */
    public int getRent3() {
        return rent3;
    }

    /**
     * Returns the rent cost of landing on this {@code Railroad}'s tile if the
     * owner owns 4 railroads.
     * 
     * @return The rent cost of landing on this {@code Railroad}'s tile if the
     *         owner owns 4 railroads.
     * 
     */
    public int getRent4() {
        return rent4;
    }

    /**
     * Returns the mortgage value of this {@code Railroad}.
     * 
     * @return The mortgage value of this {@code Railroad}.
     */
    @Override
    public int getMortgage() {
        return mortgage;
    }

    /**
     * Returns the image of this {@code Railroad}.
     * 
     * @return The image of this {@code Railroad}.
     */
    public int getId() {
        return id;
    }

}
