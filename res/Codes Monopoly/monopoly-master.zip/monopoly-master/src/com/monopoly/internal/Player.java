package com.monopoly.internal;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import com.monopoly.gui.Game;
import com.monopoly.internal.board.Board;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.money.Bank;
import com.monopoly.internal.money.Dollar;

/**
 * The <tt>Player</tt> class stores information about name, ID, totem, title
 * deeds and the number of wake-up cards.
 * 
 * @author Kevin Chen
 */
public class Player {

    /**
     * The longest a <tt>Player<tt>'s name can be.
     */
    public final static int MAX_CHAR_NAME = 10;

    /**
     * The shortest a <tt>Player</tt>'s name can be.
     */
    public final static int MIN_CHAR_NAME = 3;

    private final String name;
    private final int ID;
    private final ImageIcon totemImageIcon;
    private BufferedImage totem;
    private int numWakeUpCards;
    private int cash;
    private List<Dollar> dollars;
    private Vector<Property> titleDeeds;
    private int position = 0;

    /**
     * Constructs a <tt>Player</tt>, with a name, ID, cash, totem, etc.
     * 
     * @param name
     *            The <tt>Player</tt>'s name.
     * @param ID
     *            The <tt>Player</tt>'s ID.
     */
    public Player(String name, int ID) {
        this.name = name;
        this.ID = ID;
        String path = Game.TOTEM_PATH + ID + ".png";
        try {
            totem = ImageIO.read(new File(path));
        } catch (IOException e) {
            System.err.println("Cannot read Player totem at: " + path);
        }
        totemImageIcon = new ImageIcon(totem);
        numWakeUpCards = 0;
        cash = 0;
        titleDeeds = new Vector<Property>();
        dollars = new Vector<Dollar>();
    }

    /**
     * Returns this <tt>Player</tt>'s name.
     * 
     * @return This <tt>Player</tt>'s name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns this <tt>Player</tt>'s ID.
     * 
     * @return This <tt>Player</tt>'s ID.
     */
    public int getID() {
        return ID;
    }
    
    /**
     * Returns this <tt>Player</tt>'s position.
     * 
     * @return This <tt>Player</tt>'s position.
     */
    public int getPosition() {
        return position % Board.LENGTH;
    }
    
    /**
     * Sets this <tt>Player</tt>'s position.
     * @param position The new position.
     */
    public void setPosition(int position) {
        this.position = position;
    }
    
    /**
     * Moves this <tt>Player</tt> forward.
     * @param spaces The number of spaces to move forward by.
     */
    public void goForward(int spaces) {
        position += spaces;
    }
    
    /**
     * Sends this <tt>Player</tt> to jail.
     */
    public void goToJail() {
        position = 10;
    }

    /**
     * Returns this <tt>Player</tt>'s totem, represented as an
     * <tt>ImageIcon</tt>.
     * 
     * @return This <tt>Player</tt>'s totem image.
     */
    public ImageIcon getTotemImageIcon() {
        return totemImageIcon;
    }

    /**
     * Returns this <tt>Player</tt>'s totem image.
     * 
     * @return This <tt>Player</tt>'s totem image.
     */
    public BufferedImage getTotem() {
        return totem;
    }

    /**
     * Returns the number of wake-up cards this <tt>Player</tt> has.
     * 
     * @return The number of wake-up cards this <tt>Player</tt> has.
     */
    public int getNumWakeUpCards() {
        return numWakeUpCards;
    }

    /**
     * Returns the amount of cash this <tt>Player</tt> has.
     * 
     * @return The amount of cash this <tt>Player</tt> has.
     */
    public int getCash() {
        return cash;
    }

    /**
     * Returns the title deeds this <tt>Player</tt> owns.
     * 
     * @return The title deeds this <tt>Player</tt> owns.
     */
    public Vector<Property> getTitleDeeds() {
        return titleDeeds;
    }

    /**
     * Gains dollar bill(s).
     * 
     * @param dollars
     *            The array of bills received.
     */
    public void gain(List<Dollar> dollars) {
        gain(dollars.toArray(new Dollar[dollars.size()]));
    }

    /**
     * Gains dollar bill(s).
     * 
     * @param dollars
     *            The array of bills received.
     */
    public void gain(Dollar... dollars) {
        for (Dollar dollar : dollars) {
            this.dollars.add(dollar);
            this.cash += dollar.getValue();
        }
    }

    /**
     * Deducts money bills from this <tt>Player</tt>. If player has less than
     * should be deducted, then everything is deducted.
     * 
     * @param cashToLose
     *            The amount of cash to deduct.
     * @return the list of <tt>Money</tt>s that were deducted.
     */
    public List<Dollar> lose(int cashToLose) {
        Vector<Dollar> dollarsLost = new Vector<Dollar>();
        // sorts bills from smallest to biggest
        Bank.sort(dollars);
        int index = dollars.size() - 1;
        while (cashToLose > 0 && index >= 0) {
            Dollar current = dollars.get(index);
            if (current.getValue() > cashToLose) {
                index--;
                continue;
            }
            dollarsLost.add(dollars.remove(index));
            cashToLose -= current.getValue();
            this.cash -= current.getValue();
            index--;
        }
        return dollarsLost;
    }

    /**
     * Returns the list of <tt>Dollar</tt>s owned by this <tt>Player</tt>.
     * 
     * @return The list of <tt>Dollar</tt>s owned by this <tt>Player</tt>.
     */
    public List<Dollar> getDollars() {
        return dollars;
    }

    public static void main(String[] args) {

        // Does Vector remove fill the gap?
        Vector<Integer> vec = new Vector<Integer>();
        for (int i = 1; i < 5; i++)
            vec.add(i);
        for (int i = 0; i < vec.size(); i++) {
            System.out.format("%d, ", vec.get(i));
            System.out.println();
        }
        System.out.println(vec);
        vec.remove(2);
        for (int i = 0; i < vec.size(); i++) {
            System.out.format("%d, ", vec.get(i));
            System.out.println();
        }
        System.out.println(vec);
        /*
         * // Test Player#lose Player player = new Player("Kevin", 6);
         * player.gain(new Dollar(Money.M500), new Dollar(Money.M100), new
         * Dollar(Money.M100)); Bank.print(player.getDollars());
         * player.lose(400); Bank.print(player.getDollars());
         */
    }

}
