/**
 * 
 */
package com.monopoly.internal.decks;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.OwnableCard;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;

/**
 * An interface for decks whose cards can be dealt.
 * <p>
 * Applies to {@link Property} cards, {@link Utility} cards, and
 * {@link Railroad} cards.
 * <p>
 * Does not apply to Chance/{@link WhiteRussian} cards and Community Chest/
 * {@link Briefcase} cards.
 * 
 * @author kmchen1
 * 
 */
public interface Dealable {
    /**
     * Called when a card has been purchased.
     * @return The card that was purchased.
     */
    public OwnableCard deal();
    
    /**
     * Called when a card has been mortgaged.
     */
    public void mortgage(OwnableCard card);
}
