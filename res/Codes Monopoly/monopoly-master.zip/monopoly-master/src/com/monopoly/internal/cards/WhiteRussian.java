package com.monopoly.internal.cards;

/**
 * An enumeration of {@code WhiteRussian}s.
 * 
 * @author Kevin Chen
 */
public enum WhiteRussian implements NonownableCard {

    //@formatter:off
    /**
     * Pay each player $50.
     */
	WR1("Pay each player $50.", 1),
	
	/**
	 * Pass out. Do not observe Shabbos.
	 */
	WR2("Pass out. Do not observe Shabbos.", 2),
	
	/**
	 * Collect $100.
	 */
	WR3("Collect $100.", 3),
	
	/**
	 * Pay $15.
	 */
	WR4("Pay $15.", 4),
	
	/**
	 * Advance to the Dude's ride. If you observe Shabbos, collect $200.
	 */
	WR5("Advance to the Dude's ride. If you observe Shabbos, collect $200.", 5),
	
	/**
	 * Pay $150.
	 */
	WR6("Pay $150.", 6),
	
	/**
	 * Go back 3 spaces.
	 */
	WR7("Go back 3 spaces.", 7),
	
	/**
	 * Pay $50.
	 */
	WR8("Pay $50.", 8),
	
	/**
	 * Wake up.
	 */
	WR9("Wake up.", 9),
	
	/**
	 * Advance to Shabbos. Collect $200.
	 */
	WR10("Advance to Shabbos. Collect $200.", 10),
	
	/**
	 * Advance to Doctor's Office. If you observe Shabbos, collect $200.
	 */
	WR11("Advance to Doctor's Office. If you observe Shabbos, collect $200.", 11),
	
	/**
	 * Collect $50.
	 */
	WR12("Collect $50.", 12),
	
	/**
	 * Advance to Lebowski's mansion.
	 */
	WR13("Advance to Lebowski's mansion.", 13),
	
	/**
	 * Collect $150.
	 */
	WR14("Collect $150.", 14),
	
	/**
	 * Advance to nearest utility. If owned, throw dice and pay owner ten times the amount thrown.
	 */
	WR15("Advance to nearest utility. If owned, throw dice and pay owner ten times the amount thrown.", 15),
	
	/**
	 * Advance to nearest car. Pay owner twice the rental.
	 */
	WR16("Advance to nearest car. Pay owner twice the rental.", 16),
	
	/**
	 * Pay $25 for each house, $100 for each hotel.
	 */
	WR17("Pay $25 for each house, $100 for each hotel.", 17);
	//@formatter:on

    private final String description;
    private final int id;

    /**
     * Constructs a {@code WhiteRussian}.
     * 
     * @param description
     *            This {@code WhiteRussian}'s description.
     * @param id
     *            This {@code WhiteRussian}'s ID.
     */
    WhiteRussian(String description, int id) {
        this.description = description;
        this.id = id;
    }

    /**
     * Returns this {@code WhiteRussian}'s ID.
     * 
     * @return This {@code WhiteRussian}'s ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Returns this {@code WhiteRussian}'s description.
     * 
     * @return This {@code WhiteRussian}'s description.
     */
    public String getDescription() {
        return description;
    }
}
