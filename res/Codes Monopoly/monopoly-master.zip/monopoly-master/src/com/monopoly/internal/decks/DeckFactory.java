/**
 * 
 */
package com.monopoly.internal.decks;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.NonownableCard;
import com.monopoly.internal.cards.OwnableCard;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;

/**
 * A factory of utility methods to construct two decks, from each of the two
 * types of {@link NonownableCard}s:
 * <ul>
 * <li>{@link Briefcase} decks</li>
 * <li>{@link WhiteRussian} decks</li>
 * </ul>
 * and from each of the three types of {@link OwnableCard}s:
 * <ul>
 * <li>{@link Property} decks</li>
 * <li>{@link Railroad} decks</li>
 * <li>{@link Utility} decks</li>
 * </ul>
 * 
 * @author kmchen1
 * 
 */
public class DeckFactory {

    /**
     * Returns a deck of {@code Briefcase} cards.
     * 
     * @return a deck of {@code Briefcase} cards.
     */
    public static NonownableDeck newBriefcaseDeck() {
        return new NonownableDeck(Briefcase.class);
    }

    /**
     * Returns a deck of {@code WhiteRussian} cards.
     * 
     * @return a deck of {@code WhiteRussian} cards.
     */
    public static NonownableDeck newWhiteRussianDeck() {
        return new NonownableDeck(WhiteRussian.class);
    }

    /**
     * Returns a deck of {@code Property} cards.
     * 
     * @return a deck of {@code Property} cards.
     */
    public static OwnableDeck newPropertyDeck() {
        return new OwnableDeck(Property.class);
    }

    /**
     * Returns a deck of {@code Railroad} cards.
     * 
     * @return a deck of {@code Railroad} cards.
     */
    public static OwnableDeck newRailroadDeck() {
        return new OwnableDeck(Railroad.class);
    }

    /**
     * Returns a deck of {@code Utility} cards.
     * 
     * @return a deck of {@code Utility} cards.
     */
    public static OwnableDeck newUtilityDeck() {
        return new OwnableDeck(Utility.class);
    }

}
