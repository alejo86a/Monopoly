package com.monopoly.internal.board;

import java.awt.Color;

import com.monopoly.internal.cards.Property;

/**
 * An enum to be used later for grouping properties. Will come in handy to
 * evaluate monopolies.
 * 
 * @author Kevin Chen
 */
public enum PropertyColor {
    //@formatter:off
	PURPLE(69, 3, 42),
	LIGHT_BLUE(115, 146, 204),
	PINK(181, 29, 84),
	ORANGE(240, 107, 27),
	RED(230, 34, 27),
	YELLOW(250, 229, 10),
	GREEN(25, 151, 73),
	BLUE(30, 57, 144);
	//@formatter:on

    private final Color color;

    /**
     * Constructs a {@code PropertyColor} for the {@link Property}s.
     * 
     * @param r
     *            This {@code PropertyColor}'s R value.
     * @param g
     *            This {@code PropertyColor}'s G value.
     * @param b
     *            This {@code PropertyColor}'s B value.
     */
    PropertyColor(final int r, final int g, final int b) {
        color = new Color(r, g, b);
    }

    /**
     * Returns this {@code PropertyColor}'s color.
     * 
     * @return This {@code PropertyColor}'s color.
     */
    public Color getColor() {
        return color;
    }

}
