/**
 * 
 */
package com.monopoly.internal.cards;

/**
 * @author kmchen1
 * 
 */
public interface OwnableCard extends Card {
    /**
     * Returns the card's mortgage value.
     * 
     * @return the card's mortgage value.
     */
    public int getMortgage();
}
