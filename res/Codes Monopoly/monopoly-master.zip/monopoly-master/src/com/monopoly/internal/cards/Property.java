package com.monopoly.internal.cards;

import com.monopoly.internal.board.PropertyColor;

/**
 * An enumeration of Property (real estate) cards.
 * <p>
 * If a player owns all the lots of any Color Group, the rent is doubled on
 * unimproved lots in that group.
 * 
 * @author Kevin Chen
 */
public enum Property implements OwnableCard {
    //@formatter:off
    /**
     * Dude's Bachelor Pad. <p>
     * Rent with 0 Houses   $2 <p>
     * Rent with 1 House    $10 <p>
     * Rent with 2 Houses   $30 <p>
     * Rent with 3 Houses   $90 <p>
     * Rent with 4 Houses   $160 <p>
     * Rent with Hotel      $250 <p>
     * Mortgage Value       $30 <p>
     * Houses cost          $50 each <p>
     * Hotels cost $50, plus four houses
     */
	DUDES_BACHELOR_PAD("Dude's Bachelor Pad", PropertyColor.PURPLE, 2, 10, 30, 90, 160, 250, 30, 50, 50, 1),

    /**
     * West Hollywood. <p>
     * Rent with 0 Houses   $4 <p>
     * Rent with 1 House    $20 <p>
     * Rent with 2 Houses   $60 <p>
     * Rent with 3 Houses   $180 <p>
     * Rent with 4 Houses   $320 <p>
     * Rent with Hotel      $450 <p>
     * Mortgage Value       $30 <p>
     * Houses cost          $50 each <p>
     * Hotels cost $50, plus four houses
     */
	WEST_HOLLYWOOD("West Hollywood", PropertyColor.PURPLE, 4, 20, 60, 180, 320, 450, 30, 50, 50, 2),
	
    /**
     * Coffee Shop. <p>
     * Rent with 0 Houses   $6 <p>
     * Rent with 1 House    $30 <p>
     * Rent with 2 Houses   $90 <p>
     * Rent with 3 Houses   $270 <p>
     * Rent with 4 Houses   $400 <p>
     * Rent with Hotel      $550 <p>
     * Mortgage Value       $50 <p>
     * Houses cost          $50 each <p>
     * Hotels cost $50, plus four houses
     */
	COFFEE_SHOP("Coffee Shop", PropertyColor.LIGHT_BLUE, 6, 30, 90, 270, 400, 550, 50, 50, 50, 3),

    /**
     * Impound Lot. <p>
     * Rent with 0 Houses   $6 <p>
     * Rent with 1 House    $30 <p>
     * Rent with 2 Houses   $90 <p>
     * Rent with 3 Houses   $270 <p>
     * Rent with 4 Houses   $400 <p>
     * Rent with Hotel      $550 <p>
     * Mortgage Value       $50 <p>
     * Houses cost          $50 each <p>
     * Hotels cost $50, plus four houses
     */
	IMPOUND_LOT("Impound Lot", PropertyColor.LIGHT_BLUE, 6, 30, 90, 270, 400, 550, 50, 50, 50, 4),
	
    /**
     * Bowling Alley. <p>
     * Rent with 0 Houses   $8 <p>
     * Rent with 1 House    $40 <p>
     * Rent with 2 Houses   $100 <p>
     * Rent with 3 Houses   $300 <p>
     * Rent with 4 Houses   $450 <p>
     * Rent with Hotel      $600 <p>
     * Mortgage Value       $60 <p>
     * Houses cost          $50 each <p>
     * Hotels cost $50, plus four houses
     */
	BOWLING_ALLEY("The Bowling Alley", PropertyColor.LIGHT_BLUE, 8, 40, 100, 300, 450, 600, 60, 50, 50, 5),
	
    /**
     * Nihilist's Diner. <p>
     * Rent with 0 Houses   $10 <p>
     * Rent with 1 House    $50 <p>
     * Rent with 2 Houses   $150 <p>
     * Rent with 3 Houses   $450 <p>
     * Rent with 4 Houses   $625 <p>
     * Rent with Hotel      $750 <p>
     * Mortgage Value       $70 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	NIHILISTS_DINER("Nihilist's Diner", PropertyColor.PINK, 10, 50, 150, 450, 625, 750, 70, 100, 100, 6),
	
    /**
     * CJ's Fountain Theatre. <p>
     * Rent with 0 Houses   $10 <p>
     * Rent with 1 House    $50 <p>
     * Rent with 2 Houses   $150 <p>
     * Rent with 3 Houses   $450 <p>
     * Rent with 4 Houses   $625 <p>
     * Rent with Hotel      $750 <p>
     * Mortgage Value       $70 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	CJS_FOUNTAIN_THEATRE("CJ's Fountain Theatre", PropertyColor.PINK, 10, 50, 150, 450, 625, 750, 70, 100, 100, 7),
	
    /**
     * Ralphs. <p>
     * Rent with 0 Houses   $12 <p>
     * Rent with 1 House    $60 <p>
     * Rent with 2 Houses   $180 <p>
     * Rent with 3 Houses   $500 <p>
     * Rent with 4 Houses   $700 <p>
     * Rent with Hotel      $900 <p>
     * Mortgage Value       $80 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	RALPHS("Ralphs", PropertyColor.PINK, 12, 60, 180, 500, 700, 900, 80, 100, 100, 8),
	
    /**
     * Langdok. <p>
     * Rent with 0 Houses   $14 <p>
     * Rent with 1 House    $70 <p>
     * Rent with 2 Houses   $200 <p>
     * Rent with 3 Houses   $550 <p>
     * Rent with 4 Houses   $750 <p>
     * Rent with Hotel      $950 <p>
     * Mortgage Value       $90 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	LANGDOK("Langdok", PropertyColor.ORANGE, 14, 70, 200, 550, 750, 950, 90, 100, 100, 9),
	
    /**
     * Khe Sanh. <p>
     * Rent with 0 Houses   $14 <p>
     * Rent with 1 House    $70 <p>
     * Rent with 2 Houses   $200 <p>
     * Rent with 3 Houses   $550 <p>
     * Rent with 4 Houses   $750 <p>
     * Rent with Hotel      $950 <p>
     * Mortgage Value       $90 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	KHE_SANH("Khe Sanh", PropertyColor.ORANGE, 14, 70, 200, 550, 750, 950, 90, 100, 100, 10),
	
    /**
     * Hill 364. <p>
     * Rent with 0 Houses   $16 <p>
     * Rent with 1 House    $80 <p>
     * Rent with 2 Houses   $220 <p>
     * Rent with 3 Houses   $600 <p>
     * Rent with 4 Houses   $800 <p>
     * Rent with Hotel      $1000 <p>
     * Mortgage Value       $100 <p>
     * Houses cost          $100 each <p>
     * Hotels cost $100, plus four houses
     */
	HILL_364("Hill 364", PropertyColor.ORANGE, 16, 80, 220, 600, 800, 1000, 100, 100, 100, 11),
	
    /**
     * Doctor's Office. <p>
     * Rent with 0 Houses   $18 <p>
     * Rent with 1 House    $90 <p>
     * Rent with 2 Houses   $250 <p>
     * Rent with 3 Houses   $700 <p>
     * Rent with 4 Houses   $875 <p>
     * Rent with Hotel      $1050 <p>
     * Mortgage Value       $110 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	DOCTORS_OFFICE("Doctor's Office", PropertyColor.RED, 18, 90, 250, 700, 875, 1050, 110, 150, 150, 12),

    /**
     * In-N-Out Burger. <p>
     * Rent with 0 Houses   $18 <p>
     * Rent with 1 House    $90 <p>
     * Rent with 2 Houses   $250 <p>
     * Rent with 3 Houses   $700 <p>
     * Rent with 4 Houses   $875 <p>
     * Rent with Hotel      $1050 <p>
     * Mortgage Value       $110 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	IN_N_OUT_BURGER("In-N-Out Burger", PropertyColor.RED, 18, 90, 250, 700, 875, 1050, 110, 150, 150, 13),
	
    /**
     * Larry Seller's House. <p>
     * Rent with 0 Houses   $20 <p>
     * Rent with 1 House    $100 <p>
     * Rent with 2 Houses   $300 <p>
     * Rent with 3 Houses   $750 <p>
     * Rent with 4 Houses   $925 <p>
     * Rent with Hotel      $1100 <p>
     * Mortgage Value       $120 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	LARRY_SELLERS_HOUSE("Larry Seller's House", PropertyColor.RED, 20, 100, 300, 750, 925, 1100, 120, 150, 150, 14),
	
    /**
     * Maude's Apartment. <p>
     * Rent with 0 Houses   $22 <p>
     * Rent with 1 House    $110 <p>
     * Rent with 2 Houses   $330 <p>
     * Rent with 3 Houses   $800 <p>
     * Rent with 4 Houses   $975 <p>
     * Rent with Hotel      $1150 <p>
     * Mortgage Value       $130 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	MAUDES_APARTMENT("Maude's Apartment", PropertyColor.YELLOW, 22, 110, 330, 800, 975, 1150, 130, 150, 150, 15),
	
    /**
     * Maude's Bedroom. <p>
     * Rent with 0 Houses   $22 <p>
     * Rent with 1 House    $110 <p>
     * Rent with 2 Houses   $330 <p>
     * Rent with 3 Houses   $800 <p>
     * Rent with 4 Houses   $975 <p>
     * Rent with Hotel      $1150 <p>
     * Mortgage Value       $130 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	MAUDES_BEDROOM("Maude's Bedroom", PropertyColor.YELLOW, 22, 110, 330, 800, 975, 1150, 130, 150, 150, 16),
	
    /**
     * Maude's Art Studio. <p>
     * Rent with 0 Houses   $24 <p>
     * Rent with 1 House    $120 <p>
     * Rent with 2 Houses   $360 <p>
     * Rent with 3 Houses   $850 <p>
     * Rent with 4 Houses   $1025 <p>
     * Rent with Hotel      $1200 <p>
     * Mortgage Value       $140 <p>
     * Houses cost          $150 each <p>
     * Hotels cost $150, plus four houses
     */
	MAUDES_ART_STUDIO("Maude's Art Studio", PropertyColor.YELLOW, 24, 120, 360, 850, 1025, 1200, 140, 150, 150, 17),
	
    /**
     * Jackie Treehorn's Complex. <p>
     * Rent with 0 Houses   $26 <p>
     * Rent with 1 House    $130 <p>
     * Rent with 2 Houses   $390 <p>
     * Rent with 3 Houses   $900 <p>
     * Rent with 4 Houses   $1100 <p>
     * Rent with Hotel      $1275 <p>
     * Mortgage Value       $150 <p>
     * Houses cost          $200 each <p>
     * Hotels cost $200, plus four houses
     */
	JACKIE_TREEHORNS_COMPLEX("Jackie Treehorn's Complex", PropertyColor.GREEN, 26, 130, 390, 900, 1100, 1275, 150, 200, 200, 18),
	
    /**
     * Malibu Beach Community. <p>
     * Rent with 0 Houses   $26 <p>
     * Rent with 1 House    $130 <p>
     * Rent with 2 Houses   $390 <p>
     * Rent with 3 Houses   $900 <p>
     * Rent with 4 Houses   $1100 <p>
     * Rent with Hotel      $1275 <p>
     * Mortgage Value       $150 <p>
     * Houses cost          $200 each <p>
     * Hotels cost $200, plus four houses
     */
	MALIBU_BEACH_COMMUNITY("Malibu Beach Community", PropertyColor.GREEN, 26, 130, 390, 900, 1100, 1275, 150, 200, 200, 19),
	
    /**
     * Naked Party Beach. <p>
     * Rent with 0 Houses   $28 <p>
     * Rent with 1 House    $150 <p>
     * Rent with 2 Houses   $450 <p>
     * Rent with 3 Houses   $1000 <p>
     * Rent with 4 Houses   $1200 <p>
     * Rent with Hotel      $1400 <p>
     * Mortgage Value       $160 <p>
     * Houses cost          $200 each <p>
     * Hotels cost $200, plus four houses
     */
	NAKED_PARTY_BEACH("Naked Party Beach", PropertyColor.GREEN, 28, 150, 450, 1000, 1200, 1400, 160, 200, 200, 20),
	
    /**
     * Bunny's Poolhouse. <p>
     * Rent with 0 Houses   $35 <p>
     * Rent with 1 House    $175 <p>
     * Rent with 2 Houses   $500 <p>
     * Rent with 3 Houses   $1100 <p>
     * Rent with 4 Houses   $1300 <p>
     * Rent with Hotel      $1500 <p>
     * Mortgage Value       $175 <p>
     * Houses cost          $200 each <p>
     * Hotels cost $200, plus four houses
     */
	BUNNYS_POOLHOUSE("Bunny's Poolhouse", PropertyColor.BLUE, 35, 175, 500, 1100, 1300, 1500, 175, 200, 200, 21),
	
    /**
     * Lebowski's Mansion. <p>
     * Rent with 0 Houses   $50 <p>
     * Rent with 1 House    $200 <p>
     * Rent with 2 Houses   $600 <p>
     * Rent with 3 Houses   $1400 <p>
     * Rent with 4 Houses   $1700 <p>
     * Rent with Hotel      $2000 <p>
     * Mortgage Value       $200 <p>
     * Houses cost          $200 each <p>
     * Hotels cost $200, plus four houses
     */
	LEBOWSKIS_MANSION("Lebowski's Mansion", PropertyColor.BLUE, 50, 200, 600, 1400, 1700, 2000, 200, 200, 200, 22);
	//@formatter:on

    /**
     * The description of this {@code Property}.
     */
    private final String description;

    private final PropertyColor color;
    private final int rentHouse0;
    private final int rentHouse1;
    private final int rentHouse2;
    private final int rentHouse3;
    private final int rentHouse4;
    private final int rentHotel;
    private final int mortgage;
    private final int houseCost;
    private final int hotelCost;
    private final int id;

    /**
     * Constructs a {@code Property}.
     * 
     * @param description
     *            The description of this {@code Property}.
     * @param color
     *            The color of this {@code Property}.
     * @param rentHouse0
     *            The rent cost of this {@code Property} if the owner has 0
     *            houses on it.
     * @param rentHouse1
     *            The rent cost of this {@code Property} if the owner has 1
     *            house on it.
     * @param rentHouse2
     *            The rent cost of this {@code Property} if the owner has 2
     *            houses on it.
     * @param rentHouse3
     *            The rent cost of this {@code Property} if the owner has 3
     *            houses on it.
     * @param rentHouse4
     *            The rent cost of this {@code Property} if the owner has 4
     *            houses on it.
     * @param rentHotel
     *            The rent cost of this {@code Property} if the owner has 1
     *            hotel on it.
     * @param mortgage
     *            The mortgage value of this {@code Property}.
     * @param houseCost
     *            The cost of buying a house on this {@code Property}.
     * @param hotelCost
     *            The cost of buying a hotel on this {@code Property}.
     * @param id
     *            The ID of this {@code Property}.
     */
    Property(String description, PropertyColor color, int rentHouse0, int rentHouse1, int rentHouse2, int rentHouse3, int rentHouse4, int rentHotel,
            int mortgage, int houseCost, int hotelCost, int id) {
        this.description = description;
        this.color = color;
        this.rentHouse0 = rentHouse0;
        this.rentHouse1 = rentHouse1;
        this.rentHouse2 = rentHouse2;
        this.rentHouse3 = rentHouse3;
        this.rentHouse4 = rentHouse4;
        this.rentHotel = rentHotel;
        this.mortgage = mortgage;
        this.houseCost = houseCost;
        this.hotelCost = hotelCost;
        this.id = id;
    }

    /**
     * Returns this {@code Property}'s description.
     * 
     * @return This {@code Property}'s description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns this {@code Property}'s color.
     * 
     * @return This {@code Property}'s color.
     */
    public PropertyColor getColor() {
        return color;
    }

    /**
     * Returns the rent cost of this {@code Property} with 0 houses.
     * 
     * @return The rent cost of this {@code Property} with 0 houses.
     */
    public int getRentHouse0() {
        return rentHouse0;
    }

    /**
     * Returns the rent cost of this {@code Property} with 1 house.
     * 
     * @return The rent cost of this {@code Property} with 1 house.
     */
    public int getRentHouse1() {
        return rentHouse1;
    }

    /**
     * Returns the rent cost of this {@code Property} with 2 houses.
     * 
     * @return The rent cost of this {@code Property} with 2 houses.
     */
    public int getRentHouse2() {
        return rentHouse2;
    }

    /**
     * Returns the rent cost of this {@code Property} with 3 houses.
     * 
     * @return The rent cost of this {@code Property} with 3 houses.
     */
    public int getRentHouse3() {
        return rentHouse3;
    }

    /**
     * Returns the rent cost of this {@code Property} with 4 houses.
     * 
     * @return The rent cost of this {@code Property} with 4 houses.
     */
    public int getRentHouse4() {
        return rentHouse4;
    }

    /**
     * Returns the rent cost of this {@code Property} with 1 hotel.
     * 
     * @return The rent cost of this {@code Property} with 0 hotel.
     */
    public int getRentHotel() {
        return rentHotel;
    }

    /**
     * Returns this {@code Property}'s mortgage value.
     * 
     * @return This {@code Property}'s mortgage value.
     */
    @Override
    public int getMortgage() {
        return mortgage;
    }

    /**
     * Returns the cost of buying a house on this {@code Property}.
     * 
     * @return The cost of buying a house on this {@code Property}.
     */
    public int getHouseCost() {
        return houseCost;
    }

    /**
     * Returns the cost of buying a hotel on this {@code Property}.
     * 
     * @return The cost of buying a hotel on this {@code Property}.
     */
    public int getHotelCost() {
        return hotelCost;
    }

    /**
     * Returns the ID of this {@code Property}.
     * 
     * @return The ID of this {@code Property}.
     */
    public int getId() {
        return id;
    }

}
