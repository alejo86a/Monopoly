/**
 * 
 */
package com.monopoly.internal.cards;

/**
 * @author kmchen1
 *
 */
public interface Card {
    public String getDescription();
    public int getId();    
}
