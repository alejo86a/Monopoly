package com.monopoly.internal.cards;

/**
 * An enumeration of {@code Utility}s.
 * <p>
 * If one {@code Utility} is owned, rent is 4 times amount shown on dice.
 * <p>
 * If both {@code Utility}s are owned rent is 10 times amount shown on dice.
 * 
 * @author Kevin Chen
 */
public enum Utility implements OwnableCard {

    //@formatter:off
    /**
     * Log Jammin' Cable Repair. <p>
     * Mortgage Value   $75
     */
	LOG_JAMMIN_CABLE_REPAIR("Log Jammin' Cable Repair", 75, 23),
	
	/**
	 * Da Fino's Spy Services. <p>
	 * Mortgage Value   $75
	 */
	DA_FINOS_SPY_SERVICES("Da Fino's Spy Services", 75, 24);
	//@formatter:on

    private final String description;
    private final int mortgage;
    private final int id;

    /**
     * Constructs a {@code Utility}.
     * 
     * @param description
     *            This {@code Utility}'s description.
     * @param mortgage
     *            This {@code Utility}'s mortgage value.
     * @param id
     *            This {@code Utility}'s ID.
     */
    Utility(String description, int mortgage, int id) {
        this.description = description;
        this.mortgage = mortgage;
        this.id = id;
    }

    /**
     * Returns this {@code Utility}'s description.
     * 
     * @return This {@code Utility}'s description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns this {@code Utility}'s mortgage value.
     * 
     * @return This {@code Utility}'s mortgage value.
     */
    @Override
    public int getMortgage() {
        return mortgage;
    }

    /**
     * Returns this {@code Utility}'s ID.
     * 
     * @return This {@code Utility}'s ID.
     */
    public int getId() {
        return id;
    }

}
