/**
 * 
 */
package com.monopoly.internal.cards;

/**
 * @author kmchen1
 * 
 */
public interface NonownableCard extends Card {

}
