/**
 * 
 */
package com.monopoly.internal.decks;

import java.util.ArrayList;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.OwnableCard;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;

/**
 * This class represents decks of {@link OwnableCard}s that can be dealt and
 * owned.
 * <p>
 * This class applies to {@link Property} cards, {@link Utility} cards, and
 * {@link Railroad} cards, but not Chance ({@link WhiteRussian}) cards and
 * Community Chest ( {@link Briefcase}) cards.
 * 
 * @author kmchen1
 * 
 */
public class OwnableDeck implements Dealable {

    private ArrayList<OwnableCard> deck;

    /**
     * Constructs a shuffled deck of {@code Card}s.
     * 
     * @param cardImplementation
     *            Must implement the interface {@link OwnableCard}.
     */
    public OwnableDeck(Class<? extends OwnableCard> cardImplementation) {
        deck = new ArrayList<OwnableCard>();
        OwnableCard[] values = cardImplementation.getEnumConstants();
        for (OwnableCard b : values) {
            deck.add(b);
        }
    }

    /**
     * Deals a card pulled from the top of the proverbial stack.
     * 
     * @return the first card.
     */
    @Override
    public OwnableCard deal() {
        return deck.remove(0);
    }

    /**
     * Adds the card back to the deck when a {@code Player} mortgages it.
     */
    @Override
    public void mortgage(OwnableCard card) {
        deck.add(card);
    }

}
