/**
 * 
 */
package com.monopoly.internal.decks;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;

/**
 * An interface for decks that can be shuffled.
 * <p>
 * Applies to Chance/ {@link WhiteRussian} cards and Community Chest/
 * {@link Briefcase} cards.
 * <p>
 * Does not apply to {@link Property} cards, {@link Utility} cards, and
 * {@link Railroad} cards.
 * 
 * @author kmchen1
 * 
 */
public interface Shuffleable {
    public void shuffle();
}
