/**
 * 
 */
package com.monopoly.internal.decks;

import java.util.ArrayList;
import java.util.Collections;

import com.monopoly.internal.cards.Briefcase;
import com.monopoly.internal.cards.Card;
import com.monopoly.internal.cards.NonownableCard;
import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;
import com.monopoly.internal.cards.WhiteRussian;

/**
 * This class represents decks of {@link NonownableCard}s that can be shuffled and cycled, but not
 * owned.
 * <p>
 * This class applies to Chance/{@link WhiteRussian} cards and Community Chest/
 * {@link Briefcase} cards, but not to {@link Property} cards, {@link Utility}
 * cards, and {@link Railroad} cards.
 * 
 * 
 * @author kmchen1
 * 
 */
public class NonownableDeck implements Shuffleable, Cycleable {

    private ArrayList<Card> deck;

    /**
     * Constructs a shuffled deck of {@code Card}s.
     * 
     * @param cardImplementation
     *            Must implement the interface {@link NonownableCard}.
     */
    public NonownableDeck(Class<? extends NonownableCard> cardImplementation) {
        deck = new ArrayList<Card>();
        Card[] values = cardImplementation.getEnumConstants();
        for (Card b : values) {
            deck.add(b);
        }
        shuffle();
    }

    /**
     * Shuffles the deck.
     */
    @Override
    public void shuffle() {
        Collections.shuffle(deck);
    }

    /**
     * Moves the front card to the back.
     */
    @Override
    public void cycle() {
        Card first = deck.remove(0);
        deck.add(first);
    }

}
