package com.monopoly.internal.cards;

/**
 * An enumeration of {@code Briefcase}s.
 * 
 * @author Kevin Chen
 */
public enum Briefcase implements NonownableCard {
    //@formatter:off
    /**
     * Collect $100.
     */
	B1("Collect $100.", 1),
	
	/**
	 * Pay $100.
	 */
	B2("Pay $100.", 2),
	
	/**
	 * Pass out. Do not observe Shabbos.
	 */
	B3("Pass out. Do not observe Shabbos.", 3),
	
	/**
	 * Collect $100.
	 */
	B4("Collect $100.", 4),
	
	/**
	 * Pay $150.
	 */
	B5("Pay $150.", 5),
	
	/**
	 * Pay $50.
	 */
	B6("Pay $50.", 6),
	
	/**
	 * Collect $100.
	 */
	B7("Collect $100.", 7),
	
	/**
	 * Pay $50.
	 */
	B8("Pay $50.", 8),
	
	/**
	 * Wake up.
	 */
	B9("Wake up.", 9),
	
	/**
	 * Advance to Erev Shabbos. Collect $200.
	 */
	B10("Advance to Erev Shabbos. Collect $200.", 10),
	
	/**
	 * Advance to Bowling Alley. Collect $200 if you pass Shabbos.
	 */
	B11("Advance to Bowling Alley. Collect $200 if you pass Shabbos.", 11),
	
	/**
	 * Pay $40 per house, $115 per hotel.
	 */
	B12("Pay $40 per house, $115 per hotel.", 12),
	
	/**
	 * Collect $100.
	 */
	B13("Collect $100.", 13),
	
	/**
	 * Collect $10.
	 */
	B14("Collect $10.", 14),
	
	/**
	 * Collect $75.
	 */
	B15("Collect $75.", 15),
	
	/**
	 * Collect $50 from every player.
	 */
	B16("Collect $50 from every player.", 16),
	
	/**
	 * Collect $45.
	 */
	B17("Collect $45.", 17),
	
	/**
	 * Collect $20.
	 */
	B18("Collect $20.", 18),
	
	/**
	 * Collect $25.
	 */
	B19("Collect $25.", 19);
	//@formatter:on

    private final String description;
    private final int id;

    /**
     * Constructs a {@code Briefcase}.
     * 
     * @param description
     *            This {@code Briefcase}'s description.
     * @param id
     *            This {@code Briefcase}'s ID.
     */
    Briefcase(final String description, final int id) {
        this.description = description;
        this.id = id;
    }

    /**
     * Returns this {@code Briefcase}'s description.
     * 
     * @return This {@code Briefcase}'s description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Returns this {@code Briefcase}'s ID.
     * 
     * @return This {@code Briefcase}'s ID.
     */
    public int getId() {
        return id;
    }

}
