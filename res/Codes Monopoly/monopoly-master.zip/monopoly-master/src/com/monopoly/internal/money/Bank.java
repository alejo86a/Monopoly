package com.monopoly.internal.money;

import java.util.Collections;
import java.util.List;
import java.util.Vector;

import com.monopoly.internal.Player;

/**
 * The {@code Bank} holds money and engages in transactions with {@link Player}
 * s.
 * 
 * @author Kevin Chen
 */
public class Bank {

    private int deposits;
    private List<Dollar> dollars;

    /**
     * Constructs a {@code Bank}.
     */
    public Bank() {
        resetBank();
    }

    /**
     * Returns a list of this {@code Bank}'s dollars.
     * 
     * @return A list of this {@code Bank}'s dollars.
     */
    public List<Dollar> getDollars() {
        return dollars;
    }

    /**
     * Returns a String representation of this {@code Bank}.
     * <p>
     * Useful for debug printing, as in:
     * <p>
     * {@code System.out.println(this)}
     */
    public String toString() {
        String s = "Bank Deposits: " + deposits + "\n";
        s += "1:\t" + Collections.frequency(dollars, new Dollar(Money.M1)) + "\n";
        s += "5:\t" + Collections.frequency(dollars, new Dollar(Money.M5)) + "\n";
        s += "10:\t" + Collections.frequency(dollars, new Dollar(Money.M10)) + "\n";
        s += "20:\t" + Collections.frequency(dollars, new Dollar(Money.M20)) + "\n";
        s += "50:\t" + Collections.frequency(dollars, new Dollar(Money.M50)) + "\n";
        s += "100:\t" + Collections.frequency(dollars, new Dollar(Money.M100)) + "\n";
        s += "500:\t" + Collections.frequency(dollars, new Dollar(Money.M500));
        return s;
    }

    /**
     * Returns the value of a list of {@code Dollar}s.
     * 
     * @param dollars
     *            The list of {@code Dollar}s.
     * @return The value of a list of {@code Dollar}s.
     */
    public static int valueOf(final List<Dollar> dollars) {
        int value = 0;
        for (Dollar dollar : dollars) {
            value += dollar.getValue();
        }
        return value;
    }

    /**
     * Prints a specified list of {@code Money}.
     * 
     * @param dollars
     *            A list of {@code Money}.
     */
    public static void print(final List<Dollar> dollars) {
        for (int i = 0; i < dollars.size(); i++) {
            Dollar dollar = dollars.get(i);
            System.out.format("%d", dollar.getValue());
            if (i == dollars.size() - 1)
                break;
            System.out.print(", ");
        }
        System.out.println();
    }

    /**
     * Sorts a specified list of {@code Money}.
     * 
     * @param dollars
     *            A list of {@code Money}.
     */
    public static void sort(List<Dollar> dollars) {
        Collections.sort(dollars, Dollar.comparator);
    }

    /**
     * Replenishes this {@code Bank} with 30 of each bill, or $20,580.
     */
    public void resetBank() {
        dollars = new Vector<Dollar>();
        deposits = 0;
        for (Money money : Money.values()) {
            int value = money.getValue();
            deposits += 30 * value;
            for (int i = 0; i < 30; i++) {
                dollars.add(new Dollar(value));
            }
        }
        Bank.sort(dollars);
        System.out.println(this);
    }

    /**
     * Gives cash to a {@code Player}.
     * <p>
     * Without exceeding the target amount, the {@code Bank} only gives
     * {@code Dollar}s in its possession to the target {@code Player}.
     * <p>
     * If the {@code Bank} cannot reach the target amount without exceeding it,
     * the {@code Bank} creates {@code Money}.
     * 
     * @param player
     *            The {@code Player} to give cash to.
     * @param cashToGive
     *            The amount of cash to give. The {@code Bank} prints more money
     *            if it cannot reach this target without exceeding it.
     * 
     */
    public void give(final Player player, int cashToGive) {
        Bank.sort(dollars);
        List<Dollar> dollarsGiven = new Vector<Dollar>();
        int index = dollars.size() - 1;
        while (cashToGive > 0 && index >= 0) {
            Dollar bill = dollars.get(index);
            if (bill.getValue() <= cashToGive) {
                cashToGive -= bill.getValue();
                deposits -= bill.getValue();
                dollarsGiven.add(dollars.remove(index));
            }
            index--;
        }
        player.gain(dollarsGiven);

        /*
         * If bank has more cash to give... it creates the appropriate amount of
         * cash... and gives the appropriate bills to player...
         */
        if (cashToGive > 0) {
            createMoney(cashToGive);
            give(player, cashToGive);
        }
    }

    /**
     * Adds {@code Dollar}s to this {@code Bank}.
     * 
     * @param leftToCreate
     *            The amount of money to create.
     */
    private void createMoney(int leftToCreate) {
        while (leftToCreate != 0) {
            if (leftToCreate > 500) {
                dollars.add(new Dollar(Money.M500));
                deposits += 500;
                leftToCreate -= 500;
            }
            else if (leftToCreate > 100) {
                dollars.add(new Dollar(Money.M100));
                deposits += 100;
                leftToCreate -= 100;
            }
            else if (leftToCreate > 50) {
                dollars.add(new Dollar(Money.M50));
                deposits += 50;
                leftToCreate -= 50;
            }
            else if (leftToCreate > 20) {
                dollars.add(new Dollar(Money.M20));
                deposits += 20;
                leftToCreate -= 20;
            }
            else if (leftToCreate > 10) {
                dollars.add(new Dollar(Money.M10));
                deposits += 10;
                leftToCreate -= 10;
            }
            else if (leftToCreate > 5) {
                dollars.add(new Dollar(Money.M5));
                deposits += 5;
                leftToCreate -= 5;
            }
            else if (leftToCreate == 1) {
                dollars.add(new Dollar(Money.M1));
                deposits += 1;
                leftToCreate -= 1;
            }
            else
                System.err.println("ERROR!");
        }
    }

    /**
     * Takes cash from a {@code Player}.
     * 
     * @param player
     *            The {@code Player} to take money from.
     * @param cashToTake
     *            The amount of cash to take.
     */
    public void take(final Player player, int cashToTake) {
        System.out.format("Taking %d from %s\n", cashToTake, player.getName());
        List<Dollar> dollarsTaken = player.lose(cashToTake);
        /*
         * TODO If bank didn't take enough from player,
         */
        if (Bank.valueOf(dollarsTaken) < cashToTake) {

            return;
        }
        int cashTaken = 0;
        for (Dollar dollar : dollarsTaken) {
            dollars.add(dollar);
            cashTaken += dollar.getValue();
        }
        deposits += cashTaken;
        System.out.format("Took %d from %s\n", cashTaken, player.getName());
    }

    public static void main(String[] args) {
        Bank bank = new Bank();
        Player player = new Player("Kevin", 6);
        System.out.format("%s owns %d dollars\n", player.getName(), player.getCash());
        bank.give(player, 1000);
        System.out.format("%s owns %d dollars\n", player.getName(), player.getCash());
        bank.take(player, 400);
        System.out.format("%s owns %d dollars\n", player.getName(), player.getCash());

    }

}
