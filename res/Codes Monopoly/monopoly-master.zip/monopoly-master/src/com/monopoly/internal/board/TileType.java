package com.monopoly.internal.board;

/**
 * An enumeration of tile types.
 * 
 * @author kmchen1
 * 
 */
public enum TileType {
    //@formatter:off
	PROPERTY, 
	BRIEFCASE,
	WHITERUSSIAN,
	UTILITY, 
	JAIL, 
	TOJAIL, 
	RAILROAD, 
	GUTTERBALLS, 
	FEE, 
	SHABBOS;
	//@formatter:on
}
