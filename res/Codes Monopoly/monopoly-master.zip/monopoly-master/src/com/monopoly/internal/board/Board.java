package com.monopoly.internal.board;

import com.monopoly.internal.cards.Property;
import com.monopoly.internal.cards.Railroad;
import com.monopoly.internal.cards.Utility;

/**
 * The {@code Board} class is for holding {@link Tile}s.
 * 
 * @author Kevin Chen
 */
public class Board {

    /** The number of tiles on the {@code Board}. */
    public static final int LENGTH = 40;

    // The array of 40 {@code Tile}s.
    private static final Tile[] tiles = new Tile[LENGTH];

    /**
     * Returns a specified {@code Tile} on the {@code Board}.
     * 
     * @param tileNumber
     *            The index of the {@code Tile} to retrieve.
     * @return a specified {@code Tile} on the {@code Board}.
     */
    public Tile getTile(int tileNumber) {
        if (tileNumber < 0 || tileNumber >= tiles.length) {
            throw new IllegalArgumentException("Illegal tile access.");
        }
        return tiles[tileNumber];
    }

    /**
     * Constructs a {@code Board}.
     */
    public Board() {
        initTiles();
    }

    private void initTiles() {
        tiles[0] = new Tile(TileType.SHABBOS, null);
        tiles[1] = new Tile(TileType.PROPERTY, Property.DUDES_BACHELOR_PAD);
        tiles[2] = new Tile(TileType.BRIEFCASE, null);
        tiles[3] = new Tile(TileType.PROPERTY, Property.WEST_HOLLYWOOD);
        tiles[4] = new Tile(TileType.FEE, null);
        tiles[5] = new Tile(TileType.RAILROAD, Railroad.DUDES_RIDE);
        tiles[6] = new Tile(TileType.PROPERTY, Property.COFFEE_SHOP);
        tiles[7] = new Tile(TileType.WHITERUSSIAN, null);
        tiles[8] = new Tile(TileType.PROPERTY, Property.IMPOUND_LOT);
        tiles[9] = new Tile(TileType.PROPERTY, Property.BOWLING_ALLEY);
        tiles[10] = new Tile(TileType.JAIL, null);
        tiles[11] = new Tile(TileType.PROPERTY, Property.CJS_FOUNTAIN_THEATRE);
        tiles[12] = new Tile(TileType.UTILITY, Utility.DA_FINOS_SPY_SERVICES);
        tiles[13] = new Tile(TileType.PROPERTY, Property.NIHILISTS_DINER);
        tiles[14] = new Tile(TileType.PROPERTY, Property.RALPHS);
        tiles[15] = new Tile(TileType.RAILROAD, Railroad.LEBOWSKIS_LIMO);
        tiles[16] = new Tile(TileType.PROPERTY, Property.KHE_SANH);
        tiles[17] = new Tile(TileType.BRIEFCASE, null);
        tiles[18] = new Tile(TileType.PROPERTY, Property.LANGDOK);
        tiles[19] = new Tile(TileType.PROPERTY, Property.HILL_364);
        tiles[20] = new Tile(TileType.GUTTERBALLS, null);
        tiles[21] = new Tile(TileType.PROPERTY, Property.DOCTORS_OFFICE);
        tiles[22] = new Tile(TileType.WHITERUSSIAN, null);
        tiles[23] = new Tile(TileType.PROPERTY, Property.IN_N_OUT_BURGER);
        tiles[24] = new Tile(TileType.PROPERTY, Property.LARRY_SELLERS_HOUSE);
        tiles[25] = new Tile(TileType.RAILROAD, Railroad.ANGRY_CABBY);
        tiles[26] = new Tile(TileType.PROPERTY, Property.MAUDES_BEDROOM);
        tiles[27] = new Tile(TileType.PROPERTY, Property.MAUDES_APARTMENT);
        tiles[28] = new Tile(TileType.UTILITY, Utility.LOG_JAMMIN_CABLE_REPAIR);
        tiles[29] = new Tile(TileType.PROPERTY, Property.MAUDES_ART_STUDIO);
        tiles[30] = new Tile(TileType.TOJAIL, null);
        tiles[31] = new Tile(TileType.PROPERTY, Property.MALIBU_BEACH_COMMUNITY);
        tiles[32] = new Tile(TileType.PROPERTY, Property.JACKIE_TREEHORNS_COMPLEX);
        tiles[33] = new Tile(TileType.BRIEFCASE, null);
        tiles[34] = new Tile(TileType.PROPERTY, Property.NAKED_PARTY_BEACH);
        tiles[35] = new Tile(TileType.RAILROAD, Railroad.TONYS_LIMO);
        tiles[36] = new Tile(TileType.WHITERUSSIAN, null);
        tiles[37] = new Tile(TileType.PROPERTY, Property.BUNNYS_POOLHOUSE);
        tiles[38] = new Tile(TileType.FEE, null);
        tiles[39] = new Tile(TileType.PROPERTY, Property.LEBOWSKIS_MANSION);
    }
}
