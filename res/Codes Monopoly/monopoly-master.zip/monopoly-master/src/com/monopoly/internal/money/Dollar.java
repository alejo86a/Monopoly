/**
 * 
 */
package com.monopoly.internal.money;

import java.util.Comparator;

/**
 * A class for storing {@code Money} values.
 * <p>
 * Previously, the bank and players were storing a list of {@code Money}. This
 * was failing since enums are singletons and they could only ever have at most
 * one of each bill.
 * 
 * @author kmchen1
 * 
 */
public class Dollar {

    /**
     * A {@code Comparator} to sort {@code Dollar}s from smallest to biggest.
     */
    public final static Comparator<Dollar> comparator = new Comparator<Dollar>() {
        @Override
        public int compare(Dollar o1, Dollar o2) {
            return o1.getValue() - o2.getValue();
        }
    };

    private final int value;

    /**
     * Constructs a {@code Dollar}.
     * 
     * @param value
     *            The value of this {@code Dollar}.
     */
    public Dollar(final int value) {
        this.value = value;
    }

    /**
     * Constructs a {@code Dollar}.
     * 
     * @param money
     *            The money value singleton.
     */
    public Dollar(Money money) {
        this(money.getValue());
    }

    /**
     * Indicates whether some other value (perhaps a
     * {@code Dollar}) is equal in value to this {@code Dollar}.
     */
    public boolean equals(Object o) {
        return ((Dollar) o).getValue() == this.value;
    }

    /**
     * Returns the value of this {@code Dollar}.
     * 
     * @return The value of this {@code Dollar}.
     */
    public int getValue() {
        return value;
    }

}
